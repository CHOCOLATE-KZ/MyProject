from sqlite3 import *

def create_connection(path):
    connection = None
    try:
        connection = connect(path) #соединяем sql file
        print("Success")
    except Error as e:
        print(e)
    return connection

# connection = create_connection("test.database")
#
# #создаем таблицу
CREATE_TABLE = """
    CREATE TABLE students(
        ID INT Primary Key,
        name VARCHAR(40),
        age INT,
        gpa INT,
        year_of_study INT
    )
"""
#
INSERT_VALUES = """
    INSERT INTO students VALUES(4, "Tupac", 32, 4.5, 3);
"""
#
SELECT_ALL = "SELECT * from students"
# #метод курсора, привязаны к соединению общий
# cursor = connection.cursor() #соединие с базой данной| это другой connection
# cursor.execute(SELECT_ALL) #выполнение команды.| сюда отправляем команды которые нужно вып-ть
# #connection.commit() #запоминает транкзакцию в таблице
#
# print(cursor.fetchall()) #извлекает все строки, отправляет ввиде словаря  (список)