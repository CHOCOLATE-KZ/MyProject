from sqlite3 import *
# from db import *
from db_class import *
from db import create_connection

connection = create_connection("test_database")

students = Student_Table(connection)
students.insert_student(5, "SDsa", 31, 2.0, 4)


print(students.get_all_students())


#д/з:
#сделать фун-ию delete через ID
#ЕСЛИ НЕ получиться найти ошибку с этого файла, то скинуть Зие на гитхаб
