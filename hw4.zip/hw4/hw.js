document.write(`<h3>Задачи на массивы <br>Easy:
<br> 1. В массиве, содержащем положительные и отрицательные целые числа, вычислить сумму четных положительных элементов.</h3>`)




function countEvem(end) {
    //выводит кол-во четных чисел
    for (let i = 0; i < end; i++) {
        if (i % 2 == 0) {
            count += 2
        }
    }
}


document.write(`<h3>Задачи на объекты <br> Easy:<br> 1. Создайте массив students из объектов student который будет состоять из таких ключей как name, surname, age.Вам нужно вывести всех студентов кто старше 19.(8 студентов)</h3>`)

let students = [{
    name: Maks,
    surname: Tashimbayev,
    age: 18
}, {
    name: Chris,
    surname: Alphons,
    age: 24
}, {
    name: Richard,
    surname: Serafim,
    age: 54
}, {
    name: Phelix,
    surname: Ivers,
    age: 13
}, {
    name: Larunda,
    surname: Szwarc,
    age: 34
}, {
    name: Randulf,
    surname: Vančura,
    age: 19
}, {
    name: Phaedrus,
    surname: Archer,
    age: 64
}, {
    name: Agata,
    surname: Leblanc,
    age: 4
}]


for (let item of age) {
    if (item.age >= 19) {
        document.write(`<p> ${item.age} </p>`)
    }
}


//Задачи на функций
//Easy:
//1. Создайте функцию которая выводить сумму двух значений
function sum(n1, n2) {
    return n1 + n2
}

document.write(`<p>${sum(21, 75)}</p>`)

//3. Создайте функцию которая печатает 5 раз подряд слово “Decode”

function Decode(end) {
    let Decode = 0
    for (let i = 0; i < 5;) {
        count += 1
    }
    document.write(`<p>${Decode}</p>`)
}


//2. Создайте функцию которая выводить максимум из трех чисел
var first = parseInt(prompt('Введите первое число'), 10);
var second = parseInt(prompt('Введите второе число'), 10);
var third = parseInt(prompt('Введите третье число'), 10);
var arr = [3, 5, 10, 8, 2],
    max = Math.max.apply(null, arr);

alert(max);