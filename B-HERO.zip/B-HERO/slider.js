const sliderImages = [
    'widgets/slider-img-1',
    'widgets/slider-img-2',
    'widgets/slider-img-3'
]

const outputWords = [
    'TO OUR COMPANY',
    'OUR GUEST',
    'OUR CLIENT',
]
const typeout = document.querySelector('#typeout')
let wordIndex = 0
let charIndex = 0


printWord()

function printWord() {
    if (outputWords[wordIndex].length > charIndex) { //печатает до последнии буквы имени
        typeout.innerHTML += outputWords[wordIndex].charAt(charIndex)
        charIndex += 1
            //буквы печатаются со скоростью 1.5 ms

        setTimeout(printWord, 150)
    } else {
        setTimeout(deleteWord, 50)
    }
}

//Фун-ия для удаления слова
function deleteWord() {
    if (charIndex >= 0) {
        typeout.innerHTML = outputWords[wordIndex].substr(0, charIndex)
        charIndex -= 1
        setTimeout(deleteWord, 50)
    } else {
        wordIndex += 1
        if (wordIndex >= outputWords.length) {
            wordIndex = 0
        }

        setTimeout(printWord, 150)
    }
}