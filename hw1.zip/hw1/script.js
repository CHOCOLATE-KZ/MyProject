//1 - 2 задание
var str1 = 'Привет, ';
var str2 = 'Мир!';
alert(str1 + str2);

let num1 = parseInt(prompt('Enter your number'))

//3 задание
document.write(`<p>${num1} hour = ${60*60*num1} second</p>`)

// 4 задание
document.write
var stra = 10;
var strb = 2;

document.write(stra - strb);

document.write(stra + strb);

document.write(stra * strb);

document.write(stra / strb);

//5 задание
var c = 15;
var d = 2;
var result = c + d;
document.write(`<p> (15 + 2 ) = ${ (15 + 2) / 3 } </p>`);

//6 задание
var a = 10
var b = 2
var c = 5
var result = a + b + c;
document.write(`<p> (10 + 2 + 5) / 3 = ${ (10 + 2 + 5) / 3 } </p>`);

var a = 20
var b = 65
var c = 80
var result = (a + b + c) / 3;
document.write(`<p> (20 + 65 + 80) / 3 = ${ (20 + 65 + 80) / 3 } </p>`)

//Гипотенуза по теореме Пифагора
var a = 30
var b = 50