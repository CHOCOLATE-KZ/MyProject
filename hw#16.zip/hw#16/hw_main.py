#д/з:
#сделать фун-ию delete через ID

from sqlite3 import *
from hw_class import *
from hw_sql import create_connecion

connection = create_connecion("hw1_database")

students = Student_Table(connection)
# students.insert_student(5, 'Senior', 44, 4.5, 5)
students.delete_student(5)

print(students.get_all_students())


