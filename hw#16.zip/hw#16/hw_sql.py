#д/з:
#сделать фун-ию delete через ID


from sqlite3 import *

#подключение к sql файлу
def create_connecion(path):
    connection = None
    try:
        connection = connect(path)
        print("Success")
    except Error as e:
        print(e)
    return connection

#connection = create_connecion("hw1_database") #создание файла

#Таблица
CREATE_TABLE = """
    CREATE TABLE students(
        ID INT Primary Key,
        name VARCHAR(40),
        age INT,
        gpa INT,
        year_of_study INT
    )
"""

INSERT_VALUES = """
    INSERT INTO students VALUES(3, "Man", 25, 3.5, 3);
"""
    # INSERT INTO students VALUES(1, "Dude", 27, 4.3, 4);
    # INSERT INTO students VALUES(2, "Bro", 23, 4.5, 1);
    # INSERT INTO students VALUES(3, "Man", 25, 3.5, 3);

SELECT_ALL = "SELECT * from students"

# cursor = connection.cursor()
# cursor.execute(SELECT_ALL)
# connection.commit()

# print(cursor.fetchall()) #извлекает все строки
