from sqlite3 import *

class Student_Table:
    def __init__(self, connection):
        self.connection = connection

    #SELECT
    def get_all_students(self):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * from students")
        data = cursor.fetchall()
        return data

    #INSERT
    def insert_student(self, ID, name, age, gpa, year_of_study):
        cursor = self.connection.cursor()
        cursor.execute(f" INSERT INTO students VALUES({ID}, '{name}', '{age}', '{gpa}', '{year_of_study}') ")
        self.connection.commit()
        print("Values has been Inserted")

    #DELETE [HW]
    def delete_student(self, ID):
        cursor = self.connection.cursor()
        cursor.execute(f"DELETE FROM students WHERE id = {ID};")
        self.connection.commit()
        print("Values has been Deleted")