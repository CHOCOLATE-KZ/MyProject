<?php

    if (isset($_GET['first-name']) && 
        isset($_GET['last-name']) &&
        isset($_GET['age']) &&
        isset($_GET['skill']) &&
        isset($_GET['city'])
        ){

        $fisrt = $_GET['first-name'];
        $last = $_GET['last-name'];
        $age = $_GET['age'];
        $skill = $_GET['skill'];
        $city = $_GET['city'];
    
        echo "<p>Name & Surname: $fisrt $last</p>";
        echo "<p>Age: $age</p>";
        echo "<p>Skill: $skill</p>";
        echo "<p>City or Town: $city</p>";
    }