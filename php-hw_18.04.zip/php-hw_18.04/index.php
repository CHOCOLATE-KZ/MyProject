<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HW|PHP</title>
</head>
<body>
<!-- Д/з: На PHP как на уроке сделать про себя -->
<?php
    $first = '<h3>HOME TASK</h3>';
    echo $first;

    echo "18.04 " . "| 2021";

    $name = 'Ilyas';

    echo "<p>$name</p>";
    echo "<p>WebDev-91</p>"
?>



<form action="save-data.php">

    <div>
        <i class="fas fa-arrow-down"></i><h1>Введите ваши данные снизу</h1>
        <input type="text" placeholder="Введите имя" name="first-name">
    </div>
<br>
    <div>   
        <input type="text" placeholder="Введите фамилию" name="last-name">
    </div>
<br>
    <div>   
        <input type="text" placeholder="Введите ваш возраст" name="age">
    </div>
<br>
    <div>   
        <input type="text" placeholder="Введите ваши навыки" name="skill">
    </div>
<br>
    <div>
        <input type="text" placeholder="Введите ваш город" name="city">
    </div>    
<br>
    <button>Отправить данные</button>
</form>



</body>
</html>