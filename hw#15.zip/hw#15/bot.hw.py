import random

from telebot import *  #бот
from gtts import *     #аудио
import time

TOKEN = "1961272829:AAHo5bCjbExhA7Kikd3OtVrTDqxTbYYKNvo"
bot = TeleBot(TOKEN)


@bot.message_handler(commands=['start'])
def greeting(message):
    keyboard = types.InlineKeyboardMarkup()
    btn1 = types.InlineKeyboardButton(text="Nauryz", callback_data="btn1")
    btn2 = types.InlineKeyboardButton(text="New Year", callback_data="btn2")
    btn3 = types.InlineKeyboardButton(text="Birthday", callback_data="btn3")
    btn4 = types.InlineKeyboardButton(text="Ait", callback_data="btn4")

    keyboard.add(btn1)
    keyboard.add(btn2)
    keyboard.add(btn3)
    keyboard.add(btn4)

    bot.send_message(message.chat.id, "Choose command", reply_markup=keyboard)

@bot.callback_query_handler(func=lambda call: True)
def keyboard_function(call):
    if call.data == "btn1":  #Наурыз (картинка)
        photo = open("widgets/nauryz.jpg")
        bot.send_photo(call.message.chat.id, photo)
    elif call.data == "btn2": #New Year (аудио)  #РАБОТАЕТ
        speech = gTTS(text="Happy New Year", lang="en", slow="False")
        speech.save("audio-HappyNewYear.mp3")
        audio_t = open("audio-HappyNewYear.mp3", "rb")
        bot.send_audio(call.message.chat.id, audio_t)
    elif call.data == "btn3": #сообщение    #РАБОТАЕТ
        bot.send_message(call.message.chat.id, "Happy Birthday!")
    elif call.data == "btn4": #Ait







bot.polling()