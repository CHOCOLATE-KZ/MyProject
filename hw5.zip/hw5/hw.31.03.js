//Добавить в модальное окно текстовые поля и чтобы выглядело прилично
function openModal() {
    document.querySelector('.modal').classList.add('active')
}

function closeModal() {
    document.querySelector('.modal').classList.remove('active')
}